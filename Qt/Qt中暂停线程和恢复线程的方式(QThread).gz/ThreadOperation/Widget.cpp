#include "Widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) : QWidget(parent), ui(new Ui::Widget)
{
    ui->setupUi(this);
    m_isPause = true;
    workerThread = new WorkerThread(this);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_clicked()
{
    workerThread->myStart();
}

void Widget::on_pushButton_2_clicked()
{
    if( m_isPause )
    {
        ui->pushButton_2->setText("线程恢复");
        workerThread->pause();
        m_isPause = false;
    }
    else
    {
        ui->pushButton_2->setText("线程暂停");
        workerThread->resume();
        m_isPause = true;
    }
}


void Widget::on_pushButton_3_clicked()
{
    if( !m_isPause ) //如果目前处于暂停状态,那么需要解锁后在释放;
    {
        workerThread->resume();
    }
    workerThread->stop();
    delete workerThread;
}
