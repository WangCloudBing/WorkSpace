#ifndef WORKERTHREAD_H
#define WORKERTHREAD_H

#include <QObject>
#include <QThread>
#include <QMutex>

class WorkerThread : public QThread
{
    Q_OBJECT
public:
    explicit WorkerThread(QObject *parent = nullptr);
    ~WorkerThread();
    void myStart();
    void pause();
    void resume();
    void stop();
protected:
    void run();
signals:

public slots:

private:
    volatile bool m_isStop = false;
    QMutex m_mutex;
    volatile int i= 0;
};

#endif // WORKERTHREAD_H
