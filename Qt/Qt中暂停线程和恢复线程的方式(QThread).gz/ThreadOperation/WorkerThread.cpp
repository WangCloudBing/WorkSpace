#include "WorkerThread.h"
#include <QDebug>

WorkerThread::WorkerThread(QObject *parent) : QThread(parent)
{

}

WorkerThread::~WorkerThread()
{
    exit(0);
    wait();
}

void WorkerThread::myStart()
{
    m_isStop = false;
    start();
}

void WorkerThread::pause()
{
    m_mutex.lock();
}

void WorkerThread::resume()
{
    m_mutex.unlock();
}

void WorkerThread::stop()
{
    m_isStop = true;
}

void WorkerThread::run()
{
    while (!m_isStop)
    {
        m_mutex.lock();
        qDebug() << "Id = " << QThread::currentThreadId() << "; i = " << i;
        ++i;
        sleep(1);
        m_mutex.unlock();
    }
}
